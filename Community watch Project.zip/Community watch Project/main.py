from .storage_virtual_network import StorageVirtualNetwork
from .storage_virtual_node import StorageVirtualNode

# Create network
network = StorageVirtualNetwork()

# Create nodes
node1 = StorageVirtualNode("node1", cpu_capacity=4, memory_capacity=16, storage_capacity=500, bandwidth=1000)
node2 = StorageVirtualNode("node2", cpu_capacity=8, memory_capacity=32, storage_capacity=1000, bandwidth=2000)

# Add nodes to network
network.add_node(node1)
network.add_node(node2)

# Connect nodes with 1Gbps link
network.connect_nodes("node1", "node2", bandwidth=1000)

# Initiate file transfer (100MB file from node1 to node2)
transfer = network.initiate_file_transfer(
    source_node_id="node1",
    target_node_id="node2",
    file_name="large_dataset.zip",
    file_size=100 * 1024 * 1024  # 100MB
)

if transfer:
    print(f"Transfer initiated: {transfer.file_id}")
    
    # Process transfer in chunks
    while True:
        chunks_done, completed = network.process_file_transfer(
            source_node_id="node1",
            target_node_id="node2",
            file_id=transfer.file_id,
            chunks_per_step=3  # Process 3 chunks at a time
        )
        
        print(f"Transferred {chunks_done} chunks, completed: {completed}")
        
        if completed:
            print("Transfer completed successfully!")
            break
            
        # Get network stats
        stats = network.get_network_stats()
        print(f"Network utilization: {stats['bandwidth_utilization']:.2f}%")
        print(f"Storage utilization on node2: {node2.get_storage_utilization()['utilization_percent']:.2f}%")

        from storage_virtual_node import StorageVirtualNode
import datetime


# ---------- Community Watch Classes ----------

class User:
    def __init__(self, username: str, phone: str, address: str):
        self.username = username
        self.phone = phone
        self.address = address


class Report:
    def __init__(self, report_id: str, reporter: str, description: str,
                 file_name: str = None, file_size: int = 0, timestamp=None):
        self.report_id = report_id
        self.reporter = reporter
        self.description = description
        self.file_name = file_name
        self.file_size = file_size
        self.timestamp = timestamp or datetime.datetime.now()


class CommunityWatchSystem:
    def __init__(self, storage_node: StorageVirtualNode):
        self.storage = storage_node
        self.users = {}
        self.reports = {}

    def register_user(self, username, phone, address):
        self.users[username] = User(username, phone, address)
        print(f"[SUCCESS] User '{username}' registered.")

    def submit_report(self, username, report_id, description,
                      file_name=None, file_size=0):
        if username not in self.users:
            print("[ERROR] User does not exist.")
            return

        report = Report(report_id, username, description, file_name, file_size)
        self.reports[report_id] = report

        if file_name and file_size > 0:
            transfer = self.storage.initiate_file_transfer(report_id, file_name, file_size)
            if transfer:
                print(f"[UPLOAD STARTED] '{file_name}' ({file_size} bytes) stored in storage node {self.storage.node_id}.")
            else:
                print("[UPLOAD FAILED] Not enough space on storage node.")
        else:
            print("[INFO] Report submitted without an attachment.")

        print(f"[SUCCESS] Report '{report_id}' recorded.")


# ---------- MAIN PROGRAM ----------

if __name__ == "__main__":
    print("===== COMMUNITY WATCH NEIGHBORHOOD SYSTEM — CLOUD STORAGE ENABLED =====")

    # Create CloudSim Storage Node
    storage_node = StorageVirtualNode(
        node_id="Neighborhood_A1",
        cpu_capacity=2,
        memory_capacity=4,
        storage_capacity=10,     # 10 GB
        bandwidth=50             # 50 Mbps
    )

    # Initialize Community Watch system using the storage node
    system = CommunityWatchSystem(storage_node)

    # Sample operations (You can replace or modify)
    system.register_user("John", "670000000", "House 12")
    system.register_user("Sarah", "680123456", "House 4")

    system.submit_report(
        "John",
        "R001",
        "Suspicious movement near streetlight"
    )

    system.submit_report(
        "Sarah",
        "R002",
        "Strange vehicle parked for hours",
        file_name="vehicle.jpg",
        file_size=5 * 1024**2   # 5 MB
    )

    print("===== END OF EXECUTION =====")
