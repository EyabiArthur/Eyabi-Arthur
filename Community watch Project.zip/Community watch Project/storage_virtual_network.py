import math
from typing import Dict, List, Optional, Tuple
import hashlib
import time
from storage_virtual_node import StorageVirtualNode, FileTransfer, TransferStatus
from collections import defaultdict

class StorageVirtualNetwork:
    def __init__(self):
        self.nodes: Dict[str, StorageVirtualNode] = {}
        self.transfer_operations: Dict[str, Dict[str, FileTransfer]] = defaultdict(dict)
        
    def add_node(self, node: StorageVirtualNode):
        """Add a node to the network"""
        self.nodes[node.node_id] = node
        
    def connect_nodes(self, node1_id: str, node2_id: str, bandwidth: int):
        """Connect two nodes with specified bandwidth"""
        if node1_id in self.nodes and node2_id in self.nodes:
            self.nodes[node1_id].add_connection(node2_id, bandwidth)
            self.nodes[node2_id].add_connection(node1_id, bandwidth)
            return True
        return False
    
    def initiate_file_transfer(
        self,
        source_node_id: str,
        target_node_id: str,
        file_name: str,
        file_size: int
    ) -> Optional[FileTransfer]:
        """Initiate a file transfer between nodes"""
        if source_node_id not in self.nodes or target_node_id not in self.nodes:
            return None
            
        # Generate unique file ID
        file_id = hashlib.md5(f"{file_name}-{time.time()}".encode()).hexdigest()
        
        # Request storage on target node
        target_node = self.nodes[target_node_id]
        transfer = target_node.initiate_file_transfer(file_id, file_name, file_size, source_node_id)
        
        if transfer:
            self.transfer_operations[source_node_id][file_id] = transfer
            return transfer
        return None
    
    def process_file_transfer(
        self,
        source_node_id: str,
        target_node_id: str,
        file_id: str,
        chunks_per_step: int = 1
    ) -> Tuple[int, bool]:
        """Process a file transfer in chunks"""
        if (source_node_id not in self.nodes or 
            target_node_id not in self.nodes or
            file_id not in self.transfer_operations[source_node_id]):
            return (0, False)
            
        source_node = self.nodes[source_node_id]
        target_node = self.nodes[target_node_id]
        transfer = self.transfer_operations[source_node_id][file_id]
        
        chunks_transferred = 0
        for chunk in transfer.chunks:
            if chunk.status != TransferStatus.COMPLETED and chunks_transferred < chunks_per_step:
                if target_node.process_chunk_transfer(file_id, chunk.chunk_id, source_node_id):
                    chunks_transferred += 1
                else:
                    return (chunks_transferred, False)
        
        # Check if transfer is complete
        if transfer.status == TransferStatus.COMPLETED:
            del self.transfer_operations[source_node_id][file_id]
            return (chunks_transferred, True)
            
        return (chunks_transferred, False)
    
    def get_network_stats(self) -> Dict[str, float]:
        """Get overall network statistics"""
        total_bandwidth = sum(n.bandwidth for n in self.nodes.values())
        used_bandwidth = sum(n.network_utilization for n in self.nodes.values())
        total_storage = sum(n.total_storage for n in self.nodes.values())
        used_storage = sum(n.used_storage for n in self.nodes.values())
        
        return {
            "total_nodes": len(self.nodes),
            "total_bandwidth_bps": total_bandwidth,
            "used_bandwidth_bps": used_bandwidth,
            "bandwidth_utilization": (used_bandwidth / total_bandwidth) * 100,
            "total_storage_bytes": total_storage,
            "used_storage_bytes": used_storage,
            "storage_utilization": (used_storage / total_storage) * 100,
            "active_transfers": sum(len(t) for t in self.transfer_operations.values())
        }
    
    import math
import hashlib
import datetime
from typing import List


# ================= CLOUDSIM STORAGE CLASSES =================

class FileChunk:
    def __init__(self, chunk_id: int, size: int, checksum: str):
        self.chunk_id = chunk_id
        self.size = size
        self.checksum = checksum


class FileTransfer:
    def __init__(self, file_id: str, file_name: str, total_size: int, chunks: List[FileChunk]):
        self.file_id = file_id
        self.file_name = file_name
        self.total_size = total_size
        self.chunks = chunks


class StorageVirtualNode:
    def __init__(self, node_id: str,
                 cpu_capacity: int,
                 memory_capacity: int,
                 storage_capacity: int,
                 bandwidth: int):

        # Resource capacities
        self.node_id = node_id
        self.total_storage = storage_capacity * 1024**3
        self.bandwidth = bandwidth * 10**6

        # Utilization tracking
        self.used_storage = 0
        self.network_utilization = 0

        # Data structures
        self.active_transfers = {}
        self.stored_files = {}
        self.connections = {}

    def initiate_file_transfer(self, file_id: str,
                               file_name: str,
                               file_size: int,
                               source_node: str = None):

        # Check storage availability
        if self.used_storage + file_size > self.total_storage:
            return None

        # Generate chunks
        chunks = self._generate_chunks(file_id, file_size)
        transfer = FileTransfer(file_id, file_name, file_size, chunks)

        self.active_transfers[file_id] = transfer
        self.used_storage += file_size

        return transfer

    def _calculate_chunk_size(self, file_size: int) -> int:
        if file_size < 10 * 1024**2:
            return 512 * 1024
        elif file_size < 100 * 1024**2:
            return 2 * 1024**2
        else:
            return 10 * 1024**2

    def _generate_chunks(self, file_id: str, file_size: int) -> List[FileChunk]:
        chunk_size = self._calculate_chunk_size(file_size)
        return [
            FileChunk(
                chunk_id=i,
                size=min(chunk_size, file_size - i * chunk_size),
                checksum=hashlib.md5(f"{file_id}-{i}".encode()).hexdigest()
            )
            for i in range(math.ceil(file_size / chunk_size))
        ]


# ================= COMMUNITY WATCH CLASSES =================

class User:
    def __init__(self, username: str, phone: str, address: str):
        self.username = username
        self.phone = phone
        self.address = address


class Report:
    def __init__(self, report_id: str, reporter: str, description: str,
                 file_name: str = None, file_size: int = 0, timestamp=None):
        self.report_id = report_id
        self.reporter = reporter
        self.description = description
        self.file_name = file_name
        self.file_size = file_size
        self.timestamp = timestamp or datetime.datetime.now()


class CommunityWatch:
    def __init__(self, storage_node: StorageVirtualNode):
        self.storage_node = storage_node
        self.users = {}
        self.reports = {}

    # Register a resident
    def register_user(self, username, phone, address):
        if username in self.users:
            print("[ERROR] Username already exists.")
            return
        self.users[username] = User(username, phone, address)
        print(f"[SUCCESS] User '{username}' registered.")

    # Submit report with optional file evidence
    def submit_report(self, username, report_id, description,
                      file_name=None, file_size=0):
        if username not in self.users:
            print("[ERROR] User not found.")
            return

        report = Report(report_id, username, description, file_name, file_size)
        self.reports[report_id] = report

        if file_name and file_size > 0:
            transfer = self.storage_node.initiate_file_transfer(
                report_id, file_name, file_size
            )
            if transfer:
                print(f"[UPLOAD] File '{file_name}' successfully stored on node {self.storage_node.node_id}.")
            else:
                print("[UPLOAD FAILED] Not enough storage space on node.")
        else:
            print("[INFO] Report submitted without attachment.")

        print(f"[SUCCESS] Report '{report_id}' saved.")


# ================= DEMO (TEST RUN) =================

if __name__ == "__main__":
    print("===== COMMUNITY WATCH NEIGHBORHOOD SYSTEM — CLOUD STORAGE ACTIVE =====")

    # Create cloud virtual node for the neighborhood
    node = StorageVirtualNode("Zone_A", cpu_capacity=2, memory_capacity=4,
                              storage_capacity=10, bandwidth=50)
    system = CommunityWatch(node)

    # Demo operations
    system.register_user("John", "670000000", "House 12")
    system.register_user("Sarah", "680123456", "House 4")

    system.submit_report("John", "R001",
                         "Strange person walking around late night")

    system.submit_report("Sarah", "R002",
                         "Unknown vehicle parked for long time",
                         file_name="vehicle.jpg",
                         file_size=5 * 1024**2)  # 5 MB

    print("===== END OF EXECUTION =====")
